First use:
1. Open the file WifiCity_win.bat (double click)
2. Autorize the admin prompt window (click on yes)
3. Type 1 then press enter
4. Enter your WifiCity credential, login (enter), password (enter)
5. Close the terminal with the close icon or enter 3

Remove the set up:
1. Open the file WifiCity_win.bat (double click)
2. Autorize the admin prompt window (click on yes)
3. Type 2 then press enter
5. Close the terminal with the close icon or enter 3